
var url="public/database/movie_list.json";


const getActionMovies=async (url)=>{

    const res=await fetch(url);
    const movies=await res.json();

    const action_movies=movies.filter((m)=>m.category=='Action');

    

    action_movies.forEach((m)=>{

        var div=document.createElement("div");
        div.classList.add("action-card");
        div.innerHTML=`
        <a href="details.html" onClick="addCartAction(${m.id})">
        <img src="${m.img}" class="w-30 h-30 rounded-lg hover:cursor-pointer hover:-translate-y-1 hover:scale-110 hover:bg-indigo-500 duration-300">
        </a>`;

        document.querySelector(".action-movies").appendChild(div);

    });

}
getActionMovies(url);



function addCartAction(id){

    const getActionMovies=async (url)=>{

        const res=await fetch(url);
        const movies=await res.json();
    
        const action_movies=movies.filter((m)=>m.category=='Action');
    
    const selected_movie=action_movies.find((m)=>m.id==id);

    console.log("selected movie = ",selected_movie)
    localStorage.setItem("m",JSON.stringify(selected_movie))

    }

    getActionMovies(url);


}


/* Dramam Movies */




const getDramaMovies=async (url)=>{

    const res=await fetch(url);
    const movies=await res.json();

    const drama_movies=movies.filter((m)=>m.category=='Drama');

    drama_movies.forEach((m)=>{

        var div=document.createElement("div");
        div.classList.add("drama-card");
        div.innerHTML=`
        <a href="details.html" onClick="addCartDrama(${m.id})">
        <img src="${m.img}" class="w-30 h-30 rounded-lg hover:cursor-pointer hover:-translate-y-1 hover:scale-110 hover:bg-indigo-500 duration-300"></a>`;

        document.querySelector(".drama-movies").appendChild(div);

    });

}

getDramaMovies(url);

function addCartDrama(id){

    const getDramaMovies=async (url)=>{

        const res=await fetch(url);
        const movies=await res.json();
    
        const drama_movies=movies.filter((m)=>m.category=='Drama');
    
    const selected_movie=drama_movies.find((m)=>m.id==id);

    console.log("selected movie = ",selected_movie)
    localStorage.setItem("m",JSON.stringify(selected_movie))

    }

    getDramaMovies(url);


}

/* Scary movie */

const getScaryMovies=async (url)=>{

    const res=await fetch(url);
    const movies=await res.json();

    const scary_movies=movies.filter((m)=>m.category=='Scary');

    scary_movies.forEach((m)=>{

        var div=document.createElement("div");
        div.classList.add("scary-card");
        div.innerHTML=`
           <a href="details.html" onClick="addCartScary(${m.id})">
           <img src="${m.img}" class="w-30 h-30 rounded-lg hover:cursor-pointer hover:-translate-y-1 hover:scale-110 hover:bg-indigo-500 duration-300">
           </a>`;

        document.querySelector(".scary-movies").appendChild(div);

    });

}
getScaryMovies(url);

function addCartScary(id){

    const getScaryMovies=async (url)=>{

        const res=await fetch(url);
        const movies=await res.json();
    
        const scary_movies=movies.filter((m)=>m.category=='Scary');
    
    const selected_movie=scary_movies.find((m)=>m.id==id);

    console.log("selected movie = ",selected_movie)
    localStorage.setItem("m",JSON.stringify(selected_movie))

    }

    getScaryMovies(url);


}








